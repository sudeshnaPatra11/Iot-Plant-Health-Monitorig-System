# Plant Monitoring System — ML Prediction

Independent/reconstructed ML implementation for the plant monitoring project.

The project report describes prediction of plant moisture stress up to 4 hours ahead, but the original training dataset/code and exact ML method are not available. Therefore this repository does **not** claim to reproduce the original model. It demonstrates the same ML objective using synthetic sensor data.

## Pipeline
- 5-minute sensor sampling
- 4-hour horizon = 48 samples
- Lag and rolling moisture features
- Random Forest as the main classifier
- Logistic Regression as a simple baseline
- Chronological 70/15/15 train/validation/test split
- Accuracy, precision, recall, F1, confusion matrix and feature importance

For this demo, future soil moisture below **35% VWC** is treated as moisture stress, matching the project's stated warning threshold.

## Run
```bash
pip install -r requirements.txt
python generate_demo_data.py
python train_model.py
python predict.py
```

The included CSV is synthetic demonstration data. Its metrics must not be reported as the project's real-world 91% accuracy.
