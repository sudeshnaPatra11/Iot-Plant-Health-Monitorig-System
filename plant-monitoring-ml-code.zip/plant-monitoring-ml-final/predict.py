from pathlib import Path
import joblib, pandas as pd

bundle=joblib.load(Path("models/moisture_stress_random_forest.joblib"))
row={
"soil_moisture_vwc":37.0,"temperature_c":29.0,"humidity_rh":58.0,"light_lux":32000.0,"ph":6.4,"co2_ppm":720.0,
"moisture_change_30min":-1.8,"moisture_lag_1":37.3,"moisture_lag_2":37.6,"moisture_lag_3":37.9,
"moisture_lag_6":38.8,"moisture_lag_12":40.0,"moisture_rollmean_6":38.1,"moisture_rollmean_12":39.0}
X=pd.DataFrame([row])[bundle["features"]]
p=int(bundle["model"].predict(X)[0])
prob=float(bundle["model"].predict_proba(X)[0,1])
print("4-hour moisture-stress prediction")
print(f"Stress probability : {prob:.2%}")
print(f"Predicted state    : {'STRESS' if p else 'NORMAL'}")
