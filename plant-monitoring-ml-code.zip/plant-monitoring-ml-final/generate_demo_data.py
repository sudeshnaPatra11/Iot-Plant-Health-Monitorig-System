import numpy as np
import pandas as pd
from pathlib import Path

rng = np.random.default_rng(42)
n = 5000
step = 5
t = np.arange(n)
ts = pd.date_range("2026-01-01", periods=n, freq="5min")

day = 2*np.pi*(t % 288)/288
temp = 25 + 5*np.sin(day-np.pi/2) + rng.normal(0,.4,n)
rh = np.clip(70 - 15*np.sin(day-np.pi/2) + rng.normal(0,1.2,n), 35, 95)
light = np.clip(np.maximum(0,np.sin(day-np.pi/2))*45000 + rng.normal(0,900,n),0,60000)
ph = 6.5 + rng.normal(0,.04,n)
co2 = np.clip(750 - 180*np.sin(day-np.pi/2) + rng.normal(0,30,n),400,1200)

# Repeating dry-down cycles, with irrigation recovery.
cycle = t % 720
moisture = 75 - (cycle/720)*48 + 2*np.sin(day) + rng.normal(0,.7,n)
# add a few environmental effects
moisture -= np.maximum(temp-27,0)*0.7
moisture += np.maximum(rh-70,0)*0.08
moisture = np.clip(moisture, 18, 82)

df = pd.DataFrame({
    "timestamp": ts,
    "soil_moisture_vwc": moisture,
    "temperature_c": temp,
    "humidity_rh": rh,
    "light_lux": light,
    "ph": ph,
    "co2_ppm": co2
})
out = Path("data/sample_plant_data.csv")
df.to_csv(out,index=False)
print(f"Saved {len(df)} rows to {out}")
