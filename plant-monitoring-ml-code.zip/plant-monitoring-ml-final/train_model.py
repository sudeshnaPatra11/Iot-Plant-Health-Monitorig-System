from pathlib import Path
import json
import joblib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, classification_report, confusion_matrix

DATA = Path("data/sample_plant_data.csv")
MODELS = Path("models")
RESULTS = Path("results")
HORIZON = 48
THRESHOLD = 35.0
LAGS = [1,2,3,6,12]
ROLLS = [6,12]

def features(df):
    df=df.copy()
    df["timestamp"]=pd.to_datetime(df["timestamp"])
    df=df.sort_values("timestamp").reset_index(drop=True)
    for x in LAGS: df[f"moisture_lag_{x}"]=df.soil_moisture_vwc.shift(x)
    for x in ROLLS: df[f"moisture_rollmean_{x}"]=df.soil_moisture_vwc.rolling(x).mean()
    df["moisture_change_30min"]=df.soil_moisture_vwc-df.soil_moisture_vwc.shift(6)
    df["future_moisture"]=df.soil_moisture_vwc.shift(-HORIZON)
    df["stress"]=(df.future_moisture<THRESHOLD).astype(int)
    return df.dropna().reset_index(drop=True)

def evaluate(name, model, X, y):
    p=model.predict(X)
    m={"model":name,"accuracy":accuracy_score(y,p),"precision":precision_score(y,p,zero_division=0),"recall":recall_score(y,p,zero_division=0),"f1":f1_score(y,p,zero_division=0)}
    print("\n"+name)
    print(classification_report(y,p,digits=4,zero_division=0))
    print("Confusion matrix:\n",confusion_matrix(y,p))
    return m,p

def main():
    MODELS.mkdir(exist_ok=True); RESULTS.mkdir(exist_ok=True)
    df=features(pd.read_csv(DATA))
    cols=["soil_moisture_vwc","temperature_c","humidity_rh","light_lux","ph","co2_ppm","moisture_change_30min"]+[f"moisture_lag_{x}" for x in LAGS]+[f"moisture_rollmean_{x}" for x in ROLLS]
    X,y=df[cols],df.stress
    if y.nunique()<2: raise RuntimeError("Target contains only one class; adjust the demo data.")
    n=len(df); a=int(.70*n); b=int(.85*n)
    Xtr,ytr=X.iloc[:a],y.iloc[:a]; Xv,yv=X.iloc[a:b],y.iloc[a:b]; Xt,yt=X.iloc[b:],y.iloc[b:]
    print(f"Usable samples: {n}; train={len(Xtr)}, validation={len(Xv)}, test={len(Xt)}")
    print(f"Stress rates: train={ytr.mean():.3f}, val={yv.mean():.3f}, test={yt.mean():.3f}")

    rf=RandomForestClassifier(n_estimators=300,max_depth=12,min_samples_leaf=3,class_weight="balanced",random_state=42,n_jobs=-1)
    rf.fit(Xtr,ytr)
    lr=make_pipeline(StandardScaler(),LogisticRegression(max_iter=2000,class_weight="balanced",random_state=42))
    lr.fit(Xtr,ytr)

    vm1,_=evaluate("Random Forest — validation",rf,Xv,yv)
    vm2,_=evaluate("Logistic Regression — validation",lr,Xv,yv)
    tm1,p=evaluate("Random Forest — test",rf,Xt,yt)
    tm2,_=evaluate("Logistic Regression — test",lr,Xt,yt)
    pd.DataFrame([vm1,vm2,tm1,tm2]).to_csv(RESULTS/"metrics.csv",index=False)

    cm=confusion_matrix(yt,p)
    fig=plt.figure(figsize=(5,4)); plt.imshow(cm,interpolation="nearest"); plt.title("Random Forest — Test Confusion Matrix")
    plt.xlabel("Predicted"); plt.ylabel("Actual"); plt.xticks([0,1],["Normal","Stress"]); plt.yticks([0,1],["Normal","Stress"])
    for i in range(2):
        for j in range(2): plt.text(j,i,cm[i,j],ha="center",va="center")
    plt.tight_layout(); plt.savefig(RESULTS/"confusion_matrix.png",dpi=160); plt.close(fig)

    pd.DataFrame({"feature":cols,"importance":rf.feature_importances_}).sort_values("importance",ascending=False).to_csv(RESULTS/"feature_importance.csv",index=False)
    joblib.dump({"model":rf,"features":cols,"forecast_steps":HORIZON,"forecast_hours":4,"sampling_minutes":5,"stress_threshold_vwc":THRESHOLD},MODELS/"moisture_stress_random_forest.joblib")
    (RESULTS/"run_metadata.json").write_text(json.dumps({"data":"synthetic demonstration","forecast_hours":4,"sampling_minutes":5,"forecast_steps":48,"threshold_vwc":35,"split":"70/15/15 chronological","main_model":"Random Forest","baseline":"Logistic Regression"},indent=2))
    print("\nTraining complete.")

if __name__=="__main__": main()
